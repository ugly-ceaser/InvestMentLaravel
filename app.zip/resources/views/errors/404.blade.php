@extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('We could not find the page you were looking for.'))
