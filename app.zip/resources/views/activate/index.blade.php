<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Activate OnlineTrader</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css" />
    <style type="text/css">
        body,
        html {
            background: #F7F7F7;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="section">
            <div class="column is-6 is-offset-3">
                <h1 class="title" style="padding-top: 20px">Oops! There is nothing here. You can now install and activate from /install.</h1>
            </div>
        </div>
    </div>
    <div class="content has-text-centered">
        <p>Copyright <?php echo date('Y'); ?> Brynamics, All rights reserved.</p><br>
    </div>
</body>

</html>
