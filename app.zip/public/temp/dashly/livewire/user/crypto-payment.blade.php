
<div>
    <button type="button" class="btn btn-primary" wire:click='payViaBinance' wire:loading.attr="disabled">
        <div class="spinner-border spinner-border-sm" role="status" wire:loading>
            <span class="sr-only">Loading...</span>
        </div>
        <span>Pay Via Binance Pay</span>
    </button>
</div>
