<div class="text-center py-5">
    @include('includes.paypal')
</div>
