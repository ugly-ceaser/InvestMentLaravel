@extends('layouts.dashly')
@section('title', $title)
@section('content')
    <livewire:user.history.other-history />
@endsection
