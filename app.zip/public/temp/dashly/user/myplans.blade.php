@extends('layouts.dashly')
@section('title', $title)
@section('content')
    <livewire:user.plans.my-plans />
@endsection
