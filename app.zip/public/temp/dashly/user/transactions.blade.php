@extends('layouts.dashly')
@section('title', $title)
@section('content')
    <livewire:user.history.deposit-history />
@endsection
